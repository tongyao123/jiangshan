package com.wechat.pay.java.core.http;

/** HTTP方法 */
public enum HttpMethod {
  GET,

  PUT,

  POST,

  PATCH,

  DELETE
}
